Projeto Individual.

É uma apresentação de quem sou eu, meus hobbies e um formulario de contato sendo esse o meu primeiro projeto a ser publicado no git hub com 3 semanas de curso.
O header me basiei no projeto anterior do bookmaster onde gera uma interação entre os atributos das cores.
No resumo alem de contar um pouco da minha historia coloquei um container flex para deixar a foto e o paragrafo lado a lado.
Nos hobbies onde alem de falar mais sobre mim, utilizei apos o paragrafo um agrupador de elementos para que o formulario  ficasse centralizado e organizado.
As cores do projeto tentei deixar na cor que mais gosto "azul" fazendo uma quebra de tons para não ficar pesado nas cores.
